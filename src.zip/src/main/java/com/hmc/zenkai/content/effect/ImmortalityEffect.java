package com.hmc.zenkai.content.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import org.jetbrains.annotations.NotNull;
import com.hmc.zenkai.feature.player.PlayerLifeCycle;
import com.hmc.zenkai.feature.player.PlayerStatsAttachment;


public class ImmortalityEffect extends MobEffect {
    public ImmortalityEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xFF3AD97B);
    }

    @Override
    public boolean applyEffectTick(@NotNull LivingEntity livingEntity, int amplifier) {
        // Solo nos interesa en servidor y para jugadores
        if (!(livingEntity instanceof Player player)) {
            return true;
        }
        if (player.level().isClientSide()) {
            return true;
        }

        PlayerStatsAttachment att = PlayerStatsAttachment.get(player);

        // Si aún no usa el sistema DBR (sin raza elegida), curamos vida vanilla normal
        if (!att.isRaceChosen()) {
            float heal = 2.0F * (amplifier + 1);
            player.heal(heal);
            if (player.getHealth() > player.getMaxHealth()) {
                player.setHealth(player.getMaxHealth());
            }
            return true;
        }

        // ===== Sistema DBR: curar BODY =====
        int bodyMax = att.getBodyMax();

        // Solo cortamos si bodyMax es inválido. Antes también cortaba con bodyCur<=0, lo que dejaba
        // al inmortal atascado a 0 sin recuperarse nunca. Ahora si está a 0 también regenera.
        if (bodyMax <= 0) {
            return true;
        }

        // Ejemplo: 2% del body máximo por nivel de amplificador
        // (ajusta la fórmula a tu gusto)
        int regen = (int) Math.max(1,
                Math.round(bodyMax * 0.02 * (amplifier + 1))
        );

        att.addBody(regen); // addBody ya hace clamp a [0, bodyMax]
        int newBody = att.getBody();

        // El espejo body -> corazones vive en PlayerLifeCycle.sync(). Aquí ya no se toca la
        // vida vanilla: era la segunda copia de la misma fórmula.
        PlayerLifeCycle.syncIfServer(player);

        return true;
    }

    @Override
    public boolean shouldApplyEffectTickThisTick(int duration, int amplifier) {
        // Una vez por segundo, no por tick. Corría 20 veces más de lo que la fórmula
        // documenta y disparaba un SyncPlayerStatsPacket CADA TICK por jugador inmortal.
        return duration % 20 == 0;
    }

}