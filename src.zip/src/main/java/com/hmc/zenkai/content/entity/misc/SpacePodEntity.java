package com.hmc.zenkai.content.entity.misc;

import com.hmc.zenkai.registry.ModItems;
import com.hmc.zenkai.network.vehicle.VerticalControlVehicle;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoAnimatable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.*;
import software.bernie.geckolib.animation.AnimationState;
import software.bernie.geckolib.util.GeckoLibUtil;

public class SpacePodEntity extends Animal implements GeoEntity, VerticalControlVehicle {

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private static final RawAnimation OPEN_ANIM   = RawAnimation.begin().thenPlay("open");
    private static final RawAnimation CLOSE_ANIM  = RawAnimation.begin().thenPlay("close");
    private static final RawAnimation LAUNCH_ANIM = RawAnimation.begin().thenPlay("launch");

    // Ajustes
    private static final float  HORIZONTAL_SPEED = 1f;
    private static final double VERTICAL_SPEED   = 1.5f;   // subir/bajar (input)
    private static final double INPUT_DEADZONE   = 1.0E-3;

    // Input vertical (lo setea tu packet en servidor)
    private boolean inputUp;
    private boolean inputDown;

    public SpacePodEntity(EntityType<? extends SpacePodEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
        this.setNoAi(true);
        this.noCulling = true;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 1.0)
                .add(Attributes.MOVEMENT_SPEED, 1.0);
    }

    /** Llamar desde tu handler de packet (SERVER) */
    @Override
    public void setVerticalInput(boolean up, boolean down) {
        this.inputUp = up;
        this.inputDown = down;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 0, this::predicate)
                .triggerableAnim("open", OPEN_ANIM)
                .triggerableAnim("close", CLOSE_ANIM)
                .triggerableAnim("launch", LAUNCH_ANIM));
    }

    private <E extends GeoAnimatable> PlayState predicate(AnimationState<E> state) {
        state.setAnimation(OPEN_ANIM);
        return PlayState.CONTINUE;
    }

    // -------------------------
    // Montura + movimiento
    // -------------------------

    @Override
    protected boolean canAddPassenger(@NotNull Entity passenger) {
        return this.getPassengers().isEmpty() && passenger instanceof Player;
    }

    @Override
    public @NotNull InteractionResult mobInteract(Player player, @NotNull InteractionHand hand) {
        if (!player.isPassenger() && this.getPassengers().isEmpty()) {
            player.startRiding(this, true);
            if (!this.level().isClientSide()) triggerCloseAnimation();
            return InteractionResult.sidedSuccess(this.level().isClientSide());
        }
        return InteractionResult.PASS;
    }

    @Override
    public void travel(@NotNull Vec3 travelVector) {
        if (!this.isAlive()) return;

        LivingEntity rider = this.getControllingPassenger();

        if (this.isVehicle() && rider instanceof Player player) {

            // Mini “impulso” al despegar si está pegada al suelo
            if (this.onGround()) {
                Vec3 dm = this.getDeltaMovement();
                this.setDeltaMovement(dm.x, 0.45, dm.z);
            }

            // Rotación (yaw completo, pitch suave/clamp)
            this.setYRot(player.getYRot());
            this.yRotO = this.getYRot();

            float pitch = Mth.clamp(player.getXRot(), -25f, 25f);
            this.setXRot(pitch);
            this.xRotO = pitch;

            this.setRot(this.getYRot(), this.getXRot());
            this.yBodyRot = this.getYRot();
            this.yHeadRot = this.getYRot();

            // Input horizontal (WASD)
            float strafe  = player.xxa * 0.8f;
            float forward = player.zza;
            if (forward < 0) forward *= 0.25f;

            // Input vertical (SPACE/CTRL) desde packet
            double upDown = 0.0;
            if (inputUp) upDown += 1.0;
            if (inputDown) upDown -= 1.0;

            // Anti-drift: si no hay input, frena fuerte
            if (Math.abs(strafe) < INPUT_DEADZONE
                    && Math.abs(forward) < INPUT_DEADZONE
                    && Math.abs(upDown) < INPUT_DEADZONE) {

                Vec3 dm = this.getDeltaMovement().multiply(0.5, 0.5, 0.5);
                if (dm.lengthSqr() < 1.0E-5) dm = Vec3.ZERO;

                this.setDeltaMovement(dm);
                this.move(MoverType.SELF, this.getDeltaMovement());
                this.fallDistance = 0;

                if (this.onGround()) {
                    Vec3 d2 = this.getDeltaMovement();
                    this.setDeltaMovement(d2.x, 0.45, d2.z);
                }
                return;
            }

            Vec3 blended = computeTargetMotion(strafe, forward, upDown);

            this.setDeltaMovement(blended);
            this.hasImpulse = true;
            this.fallDistance = 0;

            this.move(MoverType.SELF, this.getDeltaMovement());
            return;
        }

        // Sin pasajero: baja suave si no está en el piso
        if (!this.isVehicle() || this.getControllingPassenger() == null) {
            double y = this.onGround() ? 0.0 : -0.05;

            this.setDeltaMovement(0.0, y, 0.0);
            this.fallDistance = 0;

            // Mantén colisiones/ajustes vanilla
            super.travel(Vec3.ZERO);
            return;
        }

        // Fallback
        this.setDeltaMovement(Vec3.ZERO);
        this.move(MoverType.SELF, Vec3.ZERO);
    }

    private @NotNull Vec3 computeTargetMotion(float strafe, float forward, double upDown) {
        float yawRad = this.getYRot() * Mth.DEG_TO_RAD;
        double sin = Math.sin(yawRad);
        double cos = Math.cos(yawRad);

        double x = (strafe * cos - forward * sin) * HORIZONTAL_SPEED;
        double z = (forward * cos + strafe * sin) * HORIZONTAL_SPEED;
        double y = upDown * VERTICAL_SPEED;

        // Suavizado leve (más fluido)
        Vec3 target = new Vec3(x, y, z);
        Vec3 cur = this.getDeltaMovement();

        return new Vec3(
                Mth.lerp(0.35, cur.x, target.x),
                Mth.lerp(0.35, cur.y, target.y),
                Mth.lerp(0.35, cur.z, target.z)
        );
    }

    @Override
    @Nullable
    public LivingEntity getControllingPassenger() {
        Entity p = this.getFirstPassenger();
        return p instanceof LivingEntity le ? le : null;
    }

    @Override
    public boolean isControlledByLocalInstance() {
        // Solo el cliente del conductor predice/mueve el pod; el resto lo recibe por tracking.
        // Antes devolvía siempre true -> todos los clientes lo movían -> desincronización en MP.
        return getControllingPassenger() instanceof Player p && p.isLocalPlayer();
    }

    @Override
    public void tick() {
        super.tick();

        boolean hasRider = this.isVehicle() && this.getControllingPassenger() != null;

        // Con rider: sin gravedad (vuelo). Sin rider: con gravedad (cae) + tu travel también baja suave.
        this.setNoGravity(hasRider);

        if (!hasRider && !this.level().isClientSide()) {
            triggerOpenAnimation();
        }
    }

    // -------------------------
    // Drops / XP
    // -------------------------

    @Override
    protected int getBaseExperienceReward() {
        return 0; // sin XP
    }

    @Override
    public boolean causeFallDamage(float fallDistance, float multiplier, @NotNull DamageSource source) {
        return false; // el space pod no recibe daño de caída
    }

    @Override
    public void die(@NotNull DamageSource source) {
        if (!this.level().isClientSide) {
            this.spawnAtLocation(ModItems.SPACE_POD_ITEM.get());
        }
        super.die(source);
    }

    // -------------------------
    // Sonidos: fuera
    // -------------------------

    @Override
    protected void playStepSound(@NotNull BlockPos pos, @NotNull BlockState state) {
        // no-op
    }

    // -------------------------
    // Asiento
    // -------------------------

    @Override
    public @NotNull Vec3 getPassengerRidingPosition(@NotNull Entity passenger) {
        Vec3 off = new Vec3(0, 0.7, -0.5);
        off = off.yRot(-this.getYRot() * Mth.DEG_TO_RAD);
        return this.position().add(off);
    }

    // -------------------------
    // GeckoLib helpers
    // -------------------------

    public void triggerCloseAnimation() { triggerAnim("controller", "close"); }
    public void triggerOpenAnimation()  { triggerAnim("controller", "open");  }
    public void triggerLaunchAnimation(){ triggerAnim("controller", "launch"); }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    // -------------------------
    // Animal abstract methods
    // -------------------------

    @Override
    public boolean isFood(@NotNull ItemStack stack) {
        return false;
    }

    @Override
    @Nullable
    public AgeableMob getBreedOffspring(@NotNull ServerLevel level, @NotNull AgeableMob partner) {
        return null;
    }
}