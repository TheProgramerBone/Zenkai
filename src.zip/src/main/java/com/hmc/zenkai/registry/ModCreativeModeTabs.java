package com.hmc.zenkai.registry;

import com.hmc.zenkai.Zenkai;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Supplier;

public class ModCreativeModeTabs {
    public static final DeferredRegister<CreativeModeTab> CREATIVE_MODE_TAB =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Zenkai.MOD_ID);

    public static final Supplier<CreativeModeTab> CREATIVE_MODE_ITEMS = CREATIVE_MODE_TAB.register("zenkai_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("creativetab.zenkai"))
                    .icon(() -> new ItemStack(ModItems.SENZU_BEAN.get()))
                    .displayItems((params, output) -> {

                        // Items a mostrar.
                        Set<Item> raceMaterialExceptions = new HashSet<>(List.of(
                                ModItems.HALO.get(),
                                ModItems.WEIGHTED_STRAPS.get(),
                                ModItems.WEIGHTED_CAPE.get()
                        ));

                        // Items a ocultar
                        Set<Item> ItemsExtraExcluded = new HashSet<>(List.of(
                                ModItems.ALL_DRAGON_BALLS_ITEM.get(),
                                ModItems.HAIR_1.get(),
                                ModItems.SSJ1_HAIR1.get(),
                                ModItems.KI_BLADE.get(),
                                ModItems.KI_SCYTHE.get(),
                                ModBlocks.HTC_PORTAL.get().asItem()
                        ));

                        ModItems.ITEMS.getEntries().forEach(supplier -> {
                            Item item = supplier.get();
                            ResourceLocation id = BuiltInRegistries.ITEM.getKey(item);
                            if (!id.getNamespace().equals(Zenkai.MOD_ID)) return;
                            boolean hideByMaterial = isRaceArmor(item) && !raceMaterialExceptions.contains(item);

                            if (hideByMaterial || ItemsExtraExcluded.contains(item)) return;

                            output.accept(item);
                        });
                    })
                    .build()
    );

    /** True si el item es una armadura cuyo material es RACE_ARMOR_MATERIAL. */
    private static boolean isRaceArmor(Item item) {
        if (!(item instanceof ArmorItem armor)) return false;
        return armor.getMaterial().equals(ModArmorMaterials.RACE_ARMOR_MATERIAL);
    }

    public static void register(IEventBus eventBus){
        CREATIVE_MODE_TAB.register(eventBus);
    }
}