package com.hmc.zenkai.registry;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.levelgen.SurfaceRules;

public class ModSurfaceRules {
    public static SurfaceRules.RuleSource makeRules() {
        Block rockyBlock = ModBlocks.ROCKY_BLOCK.get();
        SurfaceRules.RuleSource rockySurface = SurfaceRules.state(rockyBlock.defaultBlockState());

        // abovePreliminarySurface() acota la regla a la superficie REAL del terreno.
        // Sin él, ON_FLOOR/UNDER_FLOOR también aciertan en el suelo de cada cueva y el
        // bloque rocoso tapiza la columna entera hasta la bedrock.
        return SurfaceRules.ifTrue(
                SurfaceRules.abovePreliminarySurface(),                      // ⚠ API
                SurfaceRules.ifTrue(
                        SurfaceRules.isBiome(ModBiomes.ROCKY_WASTELAND),
                        SurfaceRules.sequence(
                                SurfaceRules.ifTrue(SurfaceRules.ON_FLOOR, rockySurface),
                                SurfaceRules.ifTrue(SurfaceRules.UNDER_FLOOR, rockySurface)
                        )
                )
        );
    }

    public static final SurfaceRules.RuleSource NAMEK_SURFACE_BUILDER = SurfaceRules.sequence(
            SurfaceRules.ifTrue(
                    SurfaceRules.ON_FLOOR,
                    SurfaceRules.state(ModBlocks.NAMEKIAN_GRASS_BLOCK.get().defaultBlockState())
            ),
            SurfaceRules.ifTrue(
                    SurfaceRules.UNDER_FLOOR,
                    SurfaceRules.state(ModBlocks.NAMEKIAN_DIRT.get().defaultBlockState())
            ),
            SurfaceRules.state(ModBlocks.NAMEKIAN_STONE.get().defaultBlockState())
    );
}