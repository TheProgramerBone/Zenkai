package com.hmc.zenkai.network;

import com.hmc.zenkai.Zenkai;
import com.hmc.zenkai.feature.advancement.ZenkaiTriggers;
import com.hmc.zenkai.feature.player.PlayerLifeCycle;
import com.hmc.zenkai.feature.player.PlayerStatsAttachment;
import com.hmc.zenkai.feature.Style;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.Locale;

public record ChooseStylePacket(Style style) implements CustomPacketPayload {

    public static final Type<ChooseStylePacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(
                    Zenkai.MOD_ID,
                    "choose_style"
            ));

    // Igual que en ChooseRacePacket: codec manual con writeEnum/readEnum
    public static final StreamCodec<FriendlyByteBuf, ChooseStylePacket> STREAM_CODEC =
            StreamCodec.of(ChooseStylePacket::encode, ChooseStylePacket::decode);

    // --- codec ---

    public static void encode(FriendlyByteBuf buf, ChooseStylePacket pkt) {
        buf.writeEnum(pkt.style());
    }

    public static ChooseStylePacket decode(FriendlyByteBuf buf) {
        Style style = buf.readEnum(Style.class);
        return new ChooseStylePacket(style);
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    // --- handler ---

    public static void handle(ChooseStylePacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof net.minecraft.server.level.ServerPlayer sp)) return;

            PlayerStatsAttachment att = PlayerStatsAttachment.get(sp);
            att.setStyle(pkt.style());
            att.setStyleChosen(true);
            ZenkaiTriggers.RACE_CHOSEN.get().trigger(sp,
                    att.getRace().name().toLowerCase(Locale.ROOT),
                    pkt.style().name().toLowerCase(Locale.ROOT));
            PlayerLifeCycle.sync(sp);
        });
    }
}