package com.hmc.zenkai.network;

import com.hmc.zenkai.Zenkai;
import com.hmc.zenkai.client.ClientPayloadHandlers;
import com.hmc.zenkai.client.gui.screens.ShenlongWishScreen;
import com.hmc.zenkai.client.gui.menu.StackWishMenu;
import com.hmc.zenkai.content.blockentity.NpcMarkerBlockEntity;
import com.hmc.zenkai.feature.aura.TurboPacket;
import com.hmc.zenkai.feature.aura.TurboSyncPacket;
import com.hmc.zenkai.feature.combat.BlockingPacket;
import com.hmc.zenkai.feature.combat.BlockingSyncPacket;
import com.hmc.zenkai.feature.combat.CombatModePacket;
import com.hmc.zenkai.feature.combat.CombatModeSyncPacket;
import com.hmc.zenkai.feature.forms.FormSyncPacket;
import com.hmc.zenkai.feature.ki.*;
import com.hmc.zenkai.feature.player.SyncPlayerFormPacket;
import com.hmc.zenkai.feature.player.SyncPlayerStatsPacket;
import com.hmc.zenkai.feature.player.SyncPlayerVisualPacket;
import com.hmc.zenkai.feature.race.UpdatePlayerVisualPacket;
import com.hmc.zenkai.feature.sense.*;
import com.hmc.zenkai.feature.skills.ForgetSkillPacket;
import com.hmc.zenkai.feature.skills.SkillBuyPacket;
import com.hmc.zenkai.feature.skills.SkillSyncPacket;
import com.hmc.zenkai.feature.skills.SkillTogglePacket;
import com.hmc.zenkai.feature.stats.*;
import com.hmc.zenkai.feature.technique.*;
import com.hmc.zenkai.feature.training.TrainingSwingPacket;
import com.hmc.zenkai.feature.weights.SetWeightPacket;
import com.hmc.zenkai.feature.wheel.WheelSelectPacket;
import com.hmc.zenkai.feature.wishes.*;
import com.hmc.zenkai.network.vehicle.VehicleControlPayload;
import net.minecraft.client.Minecraft;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.SimpleMenuProvider;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public class ModNetworking {
    @SubscribeEvent
    public static void register(final RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(Zenkai.MOD_ID).versioned("1");

        registrar.playToServer(
                StackWishPayload.TYPE,
                StackWishPayload.STREAM_CODEC,
                StackWishPayload.StackWishPayloadHandler::handle
        );

        registrar.playToClient(
                OpenWishScreenPayload.TYPE,
                OpenWishScreenPayload.STREAM_CODEC,
                (payload, context) -> {
                    context.enqueueWork(() -> {
                        Minecraft.getInstance().setScreen(new ShenlongWishScreen());
                    });
                }
        );

        registrar.playToServer(
                OpenStackWishPayload.TYPE,
                OpenStackWishPayload.STREAM_CODEC,
                (payload, context) -> {
                    context.enqueueWork(() -> {
                        ServerPlayer sp = (ServerPlayer) context.player();
                        sp.openMenu(new SimpleMenuProvider(
                                (id, inv, ply) -> new StackWishMenu(id, inv),
                                Component.translatable("screen.zenkai.option.stack")
                        ));
                    });
                }
        );

        registrar.playToServer(
                SetGhostSlotPayload.TYPE,
                SetGhostSlotPayload.STREAM_CODEC,
                SetGhostSlotPayload.SetGhostSlotPayloadHandler::handle
        );

        registrar.playToServer(
                WishImmortalPayload.TYPE,
                WishImmortalPayload.STREAM_CODEC,
                WishImmortalPayload.WishImmortalPayloadHandler::handle
        );

        registrar.playToServer(
                WishRevivePlayerPayload.TYPE,
                WishRevivePlayerPayload.STREAM_CODEC,
                WishRevivePlayerPayload.WishRevivePlayerPayloadHandler::handle
        );

        registrar.playToClient(
                SyncPlayerStatsPacket.TYPE,
                SyncPlayerStatsPacket.STREAM_CODEC,
                SyncPlayerStatsPacket::handle
        );

        registrar.playToClient(
                SyncPlayerFormPacket.TYPE,
                SyncPlayerFormPacket.STREAM_CODEC,
                SyncPlayerFormPacket::handle
        );

        registrar.playToClient(
                SyncPlayerVisualPacket.TYPE,
                SyncPlayerVisualPacket.STREAM_CODEC,
                SyncPlayerVisualPacket::handle
        );

        registrar.playToServer(
                SpendTpPacket.TYPE,
                SpendTpPacket.STREAM_CODEC,
                SpendTpPacket::handle);

        registrar.playToServer(
                ToggleFlyPacket.TYPE,
                ToggleFlyPacket.STREAM_CODEC,
                ToggleFlyPacket::handle);

        registrar.playToServer(
                KiChargePacket.TYPE,
                KiChargePacket.STREAM_CODEC,
                KiChargePacket::handle);
        registrar.playToServer(
                PowerPercentPacket.TYPE,
                PowerPercentPacket.STREAM_CODEC,
                PowerPercentPacket::handle);

        registrar.playToServer(
                FlyBoostPacket.TYPE,
                FlyBoostPacket.STREAM_CODEC,
                FlyBoostPacket::handle);

        registrar.playToServer(
                ChooseRacePacket.TYPE,
                ChooseRacePacket.STREAM_CODEC,
                ChooseRacePacket::handle
        );

        registrar.playToServer(
                ChooseStylePacket.TYPE,
                ChooseStylePacket.STREAM_CODEC,
                ChooseStylePacket::handle
        );

        registrar.playToServer(
                VehicleControlPayload.TYPE,
                VehicleControlPayload.STREAM_CODEC,
                VehicleControlPayload::handle
        );

        registrar.playToServer(
                TransformHoldPacket.TYPE,
                TransformHoldPacket.STREAM_CODEC,
                TransformHoldPacket::handle
        );

        registrar.playToServer(
                UpdatePlayerVisualPacket.TYPE,
                UpdatePlayerVisualPacket.STREAM_CODEC,
                UpdatePlayerVisualPacket::handle
        );

        registrar.playToServer(
                ConfirmVillagerWishPayload.TYPE,
                ConfirmVillagerWishPayload.STREAM_CODEC,
                ConfirmVillagerWishPayload.ConfirmVillagerWishPayloadHandler::handle
        );

        registrar.playToServer(
                WishTrainingPointsPayload.TYPE,
                WishTrainingPointsPayload.STREAM_CODEC,
                WishTrainingPointsPayload.WishTrainingPointsPayloadHandler::handle
        );

        registrar.playToClient(
                SyncWishTogglesPayload.TYPE,
                SyncWishTogglesPayload.STREAM_CODEC,
                (payload, context) -> context.enqueueWork(() ->
                        ClientWishToggles.apply(payload))
        );

        registrar.playToServer(
                WishRevivePetPayload.TYPE,
                WishRevivePetPayload.STREAM_CODEC,
                WishRevivePetPayload.Handler::handle
        );

        registrar.playToServer(
                SenseKiScanPacket.TYPE,
                SenseKiScanPacket.STREAM_CODEC,
                SenseKiScanPacket::handle);
        registrar.playToClient(
                SenseKiDataPacket.TYPE,
                SenseKiDataPacket.STREAM_CODEC,
                SenseKiDataPacket::handle);

        registrar.playToServer(
                ScouterScanPacket.TYPE,
                ScouterScanPacket.STREAM_CODEC,
                ScouterScanPacket::handle);
        registrar.playToClient(
                ScouterDataPacket.TYPE,
                ScouterDataPacket.STREAM_CODEC,
                ScouterDataPacket::handle);

        registrar.playToServer(
                ScouterAreaScanPacket.TYPE,
                ScouterAreaScanPacket.STREAM_CODEC,
                ScouterAreaScanPacket::handle);

        registrar.playToClient(
                ScouterAreaDataPacket.TYPE,
                ScouterAreaDataPacket.STREAM_CODEC,
                ScouterAreaDataPacket::handle);

        registrar.playToServer(
                TrainingSwingPacket.TYPE,
                TrainingSwingPacket.STREAM_CODEC,
                TrainingSwingPacket::handle);

        registrar.playToServer(
                FlyAnimPacket.TYPE,
                FlyAnimPacket.STREAM_CODEC,
                FlyAnimPacket::handle);
        registrar.playToClient(
                FlyAnimSyncPacket.TYPE,
                FlyAnimSyncPacket.STREAM_CODEC,
                FlyAnimSyncPacket::handle);

        registrar.playToServer(
                SkillBuyPacket.TYPE,
                SkillBuyPacket.STREAM_CODEC,
                SkillBuyPacket::handle);

        registrar.playToServer(
                TechniquePacket.TYPE,
                TechniquePacket.STREAM_CODEC,
                TechniquePacket::handle);

        registrar.playToServer(
                KiFirePacket.TYPE,
                KiFirePacket.STREAM_CODEC,
                KiFirePacket::handle);

        registrar.playToServer(
                CombatModePacket.TYPE,
                CombatModePacket.STREAM_CODEC,
                CombatModePacket::handle);

        registrar.playToClient(
                CombatModeSyncPacket.TYPE,
                CombatModeSyncPacket.STREAM_CODEC,
                CombatModeSyncPacket::handle);

        registrar.playToServer(
                BlockingPacket.TYPE,
                BlockingPacket.STREAM_CODEC,
                BlockingPacket::handle);

        registrar.playToClient(
                BlockingSyncPacket.TYPE,
                BlockingSyncPacket.STREAM_CODEC,
                BlockingSyncPacket::handle);

        registrar.playToClient(
                SkillSyncPacket.TYPE,
                SkillSyncPacket.STREAM_CODEC,
                SkillSyncPacket::handle);

        registrar.playToServer(
                PhysicalTechniquePacket.TYPE,
                PhysicalTechniquePacket.STREAM_CODEC,
                PhysicalTechniquePacket::handle);

        registrar.playToServer(
                PhysicalFirePacket.TYPE,
                PhysicalFirePacket.STREAM_CODEC,
                PhysicalFirePacket::handle);

        registrar.playToServer(
                TurboPacket.TYPE,
                TurboPacket.STREAM_CODEC,
                TurboPacket::handle);

        registrar.playToClient(
                TurboSyncPacket.TYPE,
                TurboSyncPacket.STREAM_CODEC,
                TurboSyncPacket::handle);

        registrar.playToClient(
                TechniqueSyncPacket.TYPE,
                TechniqueSyncPacket.STREAM_CODEC,
                TechniqueSyncPacket::handle);

        registrar.playToServer(
                LockOnPacket.TYPE,
                LockOnPacket.STREAM_CODEC,
                LockOnPacket::handle);

        registrar.playToClient(
                FormSyncPacket.TYPE,
                FormSyncPacket.STREAM_CODEC,
                FormSyncPacket::handle);

        registrar.playToServer(
                WheelSelectPacket.TYPE,
                WheelSelectPacket.STREAM_CODEC,
                WheelSelectPacket::handle);

        registrar.playToServer(
                KiChargeStartPacket.TYPE,
                KiChargeStartPacket.STREAM_CODEC,
                KiChargeStartPacket::handle);

        registrar.playToClient(
                KiChargeStatePacket.TYPE,
                KiChargeStatePacket.STREAM_CODEC,
                KiChargeStatePacket::handle);

        registrar.playToClient(
                RaceStatSyncPacket.TYPE,
                RaceStatSyncPacket.STREAM_CODEC,
                RaceStatSyncPacket::handle);

        registrar.playToServer(
                SkillTogglePacket.TYPE,
                SkillTogglePacket.STREAM_CODEC,
                SkillTogglePacket::handle);

        registrar.playToServer(
                SetWeightPacket.TYPE,
                SetWeightPacket.STREAM_CODEC,
                SetWeightPacket::handle);

        registrar.playToClient(OpenNpcMarkerPayload.TYPE, OpenNpcMarkerPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> ClientPayloadHandlers.openNpcMarker(payload)));

        registrar.playToServer(SaveNpcMarkerPayload.TYPE, SaveNpcMarkerPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> {
                    if (!(ctx.player() instanceof ServerPlayer sp)) return;
                    if (!sp.canUseGameMasterBlocks()) return;                 // creativo + permiso 2
                    if (!sp.level().isLoaded(payload.pos())) return;
                    if (sp.distanceToSqr(payload.pos().getCenter()) > 64 * 64) return;
                    if (!(sp.level().getBlockEntity(payload.pos()) instanceof NpcMarkerBlockEntity be)) return;

                    ResourceLocation type = ResourceLocation.tryParse(payload.npcType());
                    if (type == null || !BuiltInRegistries.ENTITY_TYPE.containsKey(type)) {
                        sp.sendSystemMessage(Component.translatable(
                                "messages.zenkai.npc_marker.bad_type", payload.npcType()));
                        return;
                    }
                    be.applyFrom(type, payload.yaw(), payload.offX(), payload.offY(), payload.offZ());
                    if (payload.respawn()) be.forceRespawn();
                }));

        registrar.playToServer(
                ForgetSkillPacket.TYPE,
                ForgetSkillPacket.STREAM_CODEC,
                ForgetSkillPacket::handle);

        registrar.playToClient(
                ScouterUpgradeSyncPacket.TYPE,
                ScouterUpgradeSyncPacket.STREAM_CODEC,
                ScouterUpgradeSyncPacket::handle);

        registrar.playToClient(OpenMasterPayload.TYPE, OpenMasterPayload.STREAM_CODEC,
                (payload, ctx) -> ctx.enqueueWork(() -> ClientPayloadHandlers.openMaster(payload)));
    }
}