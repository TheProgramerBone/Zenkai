package com.hmc.zenkai.feature.wishes;

import com.hmc.zenkai.client.gui.menu.StackWishMenu;
import com.hmc.zenkai.config.ServerConfig;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SetGhostSlotPayload(ItemStack chosen) implements CustomPacketPayload {
    public static final Type<SetGhostSlotPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("zenkai", "set_ghost_slot"));

    public static final StreamCodec<RegistryFriendlyByteBuf, SetGhostSlotPayload> STREAM_CODEC =
            StreamCodec.composite(
                    ItemStack.OPTIONAL_STREAM_CODEC, SetGhostSlotPayload::chosen,
                    SetGhostSlotPayload::new
            );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static class SetGhostSlotPayloadHandler {
        public static void handle(final SetGhostSlotPayload payload, final IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                ServerPlayer player = (ServerPlayer) ctx.player();
                if (!(player.containerMenu instanceof StackWishMenu menu)) return;

                ItemStack chosen = payload.chosen();
                if (chosen == null || chosen.isEmpty()) {
                    menu.clearChosenItem();
                    return;
                }

                // Validación server-side: no permitir banned items
                ResourceLocation id = BuiltInRegistries.ITEM.getKey(chosen.getItem());
                if (ServerConfig.isBanned(id)) {
                    player.displayClientMessage(Component.translatable("messages.zenkai.item_banned"), false);
                    menu.clearChosenItem();
                    return;
                }
                if (!ServerConfig.isAllowedByWhitelist(id)) {
                    player.displayClientMessage(Component.translatable("messages.zenkai.item_not_allowed"), false);
                    menu.clearChosenItem();
                    return;
                }

                // Copiar item con NBT y count=1
                ItemStack copy = chosen.copy();
                copy.setCount(1);
                menu.setChosenItem(copy);

                // El click normal deja el ítem "pegado" al cursor; lo devolvemos al
                // inventario y limpiamos el cursor para que el estado quede IGUAL que
                // tras un shift+click (cursor vacío). Sin esto, el ítem en cursor
                // interfería con la entrega al confirmar y el deseo no duplicaba.
                ItemStack carried = menu.getCarried();
                if (!carried.isEmpty()) {
                    player.getInventory().placeItemBackInInventory(carried);
                    menu.setCarried(ItemStack.EMPTY);
                }
                menu.broadcastChanges();
            });
        }
    }
}