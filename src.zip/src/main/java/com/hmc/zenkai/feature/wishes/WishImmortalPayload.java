package com.hmc.zenkai.feature.wishes;

import com.hmc.zenkai.feature.advancement.ZenkaiTriggers;
import com.hmc.zenkai.registry.ModEffects;
import com.hmc.zenkai.config.ServerConfig;
import com.hmc.zenkai.registry.ZenkaiDataAttachments;
import com.hmc.zenkai.feature.player.PlayerStatsAttachment;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record WishImmortalPayload() implements CustomPacketPayload {
    public static final Type<WishImmortalPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath("zenkai","wish_immortal"));
    public static final StreamCodec<RegistryFriendlyByteBuf, WishImmortalPayload> STREAM_CODEC =
            StreamCodec.unit(new WishImmortalPayload());
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static final class WishImmortalPayloadHandler {
        public static void handle(WishImmortalPayload payload, IPayloadContext ctx) {
            ctx.enqueueWork(() -> {
                ServerPlayer player = (ServerPlayer) ctx.player();
                if (!ServerConfig.isEnabled(ServerConfig.WishType.IMMORTAL)) {
                    player.displayClientMessage(Component.translatable("messages.zenkai.wish_disabled"), false);
                    return;
                }
                PlayerStatsAttachment att = player.getData(ZenkaiDataAttachments.PLAYER_STATS.get());
                player.addEffect(new MobEffectInstance(
                        ModEffects.IMMORTALITY,
                        MobEffectInstance.INFINITE_DURATION, 0, true, false, false
                ));
                player.displayClientMessage(Component.translatable("messages.zenkai.immortal"), false);
                att.setImmortal(true);

                WishFinalizer.finalizeWish(player, Component.translatable(
                        "messages.zenkai.wish_desc.immortal"));
                ZenkaiTriggers.WISH_GRANTED.get().trigger(player, "immortality");
            });
        }
    }
}