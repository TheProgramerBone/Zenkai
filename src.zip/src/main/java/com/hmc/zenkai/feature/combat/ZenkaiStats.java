package com.hmc.zenkai.feature.combat;

import com.hmc.zenkai.config.CommonConfig;
import com.hmc.zenkai.feature.combat.entity.EntityStatDef;
import com.hmc.zenkai.feature.combat.entity.EntityStats;
import com.hmc.zenkai.feature.combat.entity.EntityStatsManager;
import com.hmc.zenkai.feature.player.PlayerStatsAttachment;
import com.hmc.zenkai.registry.ZenkaiDataAttachments;
import com.hmc.zenkai.registry.ModGameRules;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Puente: dada cualquier entidad, devuelve su {@link ZenkaiCombatStats} (jugador o entidad con
 * stats), o null si no participa. El pipeline de combate solo habla con la interfaz.
 */
public final class ZenkaiStats {
    private ZenkaiStats() {}

    public static ZenkaiCombatStats of(Entity e) {
        if (e instanceof Player p) {
            return PlayerStatsAttachment.get(p);
        }
        if (e instanceof LivingEntity le && le.hasData(ZenkaiDataAttachments.ENTITY_STATS.get())) {
            EntityStats s = le.getData(ZenkaiDataAttachments.ENTITY_STATS.get());
            return s.isInitialized() ? s : null;
        }
        return null;
    }

    /** Los stats de entidad (no jugador) ya resueltos, o null. */
    public static EntityStats entityStats(LivingEntity le) {
        if (le instanceof Player || !le.hasData(ZenkaiDataAttachments.ENTITY_STATS.get())) return null;
        EntityStats s = le.getData(ZenkaiDataAttachments.ENTITY_STATS.get());
        return s.isInitialized() ? s : null;
    }

    /**
     * PL "de display" de CUALQUIER entidad viva (scouter / sentir ki), por prioridad:
     *  1. Jugador con raza / entidad con stats -> su PL real.
     *  2. Entidad con JSON display_only -> el PL fijo del JSON.
     *  3. Fallback vanilla -> vida_max * factor (config power_level.vanilla_factor).
     */
    public static long resolveDisplayPowerLevel(LivingEntity le) {
        // Game rule apagado: la capa Zenkai no aplica -> PL vanilla (vida_max x factor) para todos.
        if (le.getServer() == null
                || !ModGameRules.enableRaceBoosts(le.getServer())) {
            return Math.round(le.getMaxHealth() * CommonConfig.vanillaPowerLevelFactor());
        }

        ZenkaiCombatStats stats = of(le);
        if (stats != null && stats.isCombatActive()) {
            return stats.getPowerLevel();
        }
        if (!(le instanceof Player)) {
            ResourceLocation id = BuiltInRegistries.ENTITY_TYPE.getKey(le.getType());
            EntityStatDef def = EntityStatsManager.get(id);
            if (def != null && def.displayOnly()) return def.powerLevel();
        }
        return Math.round(le.getMaxHealth() * CommonConfig.vanillaPowerLevelFactor());
    }

    /**
     * Desglose de combate: [melee, defensa, kiPower]. Son los tres sumandos del PL con los
     * pesos a 1.0, así que su suma ES el power level.
     * @return null si la entidad no tiene stats del mod (mob vanilla, jugador sin raza).
     */
    public static long[] resolveBreakdown(LivingEntity le) {
        ZenkaiCombatStats s = of(le);
        if (s == null || !s.isCombatActive()) return null;
        return new long[]{
                Math.round(s.computeMeleeFinal()),
                Math.round(s.computeDefenseFinal()),
                Math.round(s.computeKiPowerFinal())
        };
    }
}