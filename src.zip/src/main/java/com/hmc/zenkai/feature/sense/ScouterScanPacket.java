package com.hmc.zenkai.feature.sense;

import com.hmc.zenkai.Zenkai;
import com.hmc.zenkai.feature.combat.ZenkaiStats;
import com.hmc.zenkai.config.CommonConfig;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * C2S: "escanea lo que tengo en la mira" (scouter). El cliente lo manda periódicamente mientras
 * el overlay del scouter está activo. Raycast AUTORITATIVO en servidor (mirada del jugador hasta
 * scouter.range). Un scouter detecta ki, no luz -> el rayo NO se corta con bloques (atraviesa
 * paredes, como el sentir ki). Responde ScouterDataPacket con el PL del objetivo (o "sin objetivo").
 */
public record ScouterScanPacket() implements CustomPacketPayload {
    public static final Type<ScouterScanPacket> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Zenkai.MOD_ID, "scouter_scan"));

    public static final StreamCodec<FriendlyByteBuf, ScouterScanPacket> STREAM_CODEC =
            StreamCodec.of((buf, pkt) -> {}, buf -> new ScouterScanPacket());

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(ScouterScanPacket pkt, IPayloadContext ctx) {
        ctx.enqueueWork(() -> {
            if (!(ctx.player() instanceof ServerPlayer sp)) return;

            double range = CommonConfig.scouterRange();
            Vec3 start = sp.getEyePosition();
            Vec3 end   = start.add(sp.getLookAngle().scale(range));
            AABB sweep = sp.getBoundingBox().expandTowards(sp.getLookAngle().scale(range)).inflate(1.0);

            EntityHitResult hit = ProjectileUtil.getEntityHitResult(sp.level(), sp, start, end, sweep,
                    e -> e instanceof LivingEntity le && le.isAlive() && !le.isSpectator() && e != sp);

            if (hit != null && hit.getEntity() instanceof LivingEntity target) {
                long pl = ZenkaiStats.resolveDisplayPowerLevel(target);
                long[] b = ZenkaiStats.resolveBreakdown(target);   // null = sin stats del mod

                // Vida: el pool del mod si lo tiene, la vanilla si no. Así el modo PODER
                // muestra vida de cualquier objetivo, tenga stats o no.
                var st = ZenkaiStats.of(target);
                boolean zenkai = st != null && st.isCombatActive();
                long hp    = zenkai ? st.getBody()    : Math.round(target.getHealth());
                long hpMax = zenkai ? st.getBodyMax() : Math.round(target.getMaxHealth());

                PacketDistributor.sendToPlayer(sp, new ScouterDataPacket(true, pl,
                        b == null ? 0L : b[0], b == null ? 0L : b[1], b == null ? 0L : b[2],
                        hp, hpMax));
            } else {
                PacketDistributor.sendToPlayer(sp, ScouterDataPacket.empty());
            }
        });
    }
}