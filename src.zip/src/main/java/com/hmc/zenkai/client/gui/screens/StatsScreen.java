package com.hmc.zenkai.client.gui.screens;

import com.hmc.zenkai.event.tick.KaiokenSystem;
import com.hmc.zenkai.feature.Race;
import com.hmc.zenkai.feature.RaceStatTable;
import com.hmc.zenkai.feature.Style;
import com.hmc.zenkai.feature.forms.FormIds;
import com.hmc.zenkai.feature.forms.KaiokenTier;
import com.hmc.zenkai.feature.skills.SkillEffects;
import com.hmc.zenkai.feature.weights.WeightSystem;
import com.hmc.zenkai.registry.ZenkaiDataAttachments;
import com.hmc.zenkai.client.gui.AlignmentPalette;
import com.hmc.zenkai.client.gui.ScreenTitle;
import com.hmc.zenkai.client.gui.buttons.PlusIconButton;
import com.hmc.zenkai.client.gui.buttons.TextOnlyButton;
import com.hmc.zenkai.config.CommonConfig;
import com.hmc.zenkai.feature.ZenkaiAttributes;
import com.hmc.zenkai.feature.player.PlayerFormAttachment;
import com.hmc.zenkai.feature.player.PlayerStatsAttachment;
import com.hmc.zenkai.feature.stats.*;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Pestaña PRINCIPAL del menú Zenkai (renovada).
 * Layout: cabecera (Race/Style/Form/TP) · izquierda atributos · derecha render del
 * jugador (hover = maestría de la forma actual) · botón que abre popup lateral con
 * stats efectivas · abajo TPC/coste + barra de alineamiento.
 */
public class StatsScreen extends ZenkaiMenuScreen {

    private static final int PAD = 8;

    // Orden de atributos (MND al final)
    private static final List<ZenkaiAttributes> ORDER = List.of(
            ZenkaiAttributes.STRENGTH, ZenkaiAttributes.DEXTERITY, ZenkaiAttributes.CONSTITUTION,
            ZenkaiAttributes.WILLPOWER, ZenkaiAttributes.SPIRIT, ZenkaiAttributes.MIND
    );

    // ── Layout ────────────────────────────────────────────────────────────────
    private static final int HEADER_Y   = CONTENT_TOP;      // 1ª línea de cabecera (rel. panelTop)
    private static final int DIV_Y      = HEADER_Y + 24;    // divisor bajo cabecera
    private static final int ATTR_Y0    = DIV_Y + 12;       // 1ª fila de atributos
    private static final int ATTR_STEP  = 20;               // paso entre filas
    private static final int PLUS_W     = 12;
    private static final int ATTR_TEXT_X = 16 + PLUS_W + 4;
    private static final int PREVIEW_X1 = 150, PREVIEW_X2 = 244;
    private static final int PREVIEW_Y1 = 48,  PREVIEW_Y2 = 172;
    private static final int ALIGN_BAR_W = 130, ALIGN_BAR_H = 7;

    // Popup de stats efectivas
    private static final int POPUP_W = 118, POPUP_H = 104;

    private static final int[] TP_STEPS = {1, 10, 100, 1000, 10000, 100000};
    private int tpStepIndex = 0;

    private int tpcLabelX, tpcLabelY, tpcLabelW, tpcLabelH;
    private int alignBarX, alignBarY;
    private boolean showEffectiveStats = false;

    private int getCurrentTpStep() { return TP_STEPS[tpStepIndex]; }
    private void cycleTpStep()     { tpStepIndex = (tpStepIndex + 1) % TP_STEPS.length; }

    private record AttrArea(ZenkaiAttributes attr, int x, int y, int w, int h) {
        boolean contains(int mx, int my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }
    private final List<AttrArea> attrAreas = new ArrayList<>();

    public StatsScreen() { super(Component.translatable("screen.zenkai.stats_screen.title")); }

    @Override protected ZenkaiTab currentTab() { return ZenkaiTab.STATS; }

    @Override
    protected void initContent() {
        int x = panelLeft + 16;
        int y = panelTop + ATTR_Y0;

        for (ZenkaiAttributes a : ORDER) {
            final String name = a.name();
            this.addRenderableWidget(new PlusIconButton(x, y + 1,
                    () -> spend(name, getCurrentTpStep())));
            y += ATTR_STEP;
        }

        // TPC + botón de multiplicador (abajo-izquierda)
        Font font = this.font;
        tpcLabelX = panelLeft + 12;
        tpcLabelY = panelTop + BG_H - 40;
        tpcLabelW = font.width("TPC: x100000");
        tpcLabelH = font.lineHeight;
        this.addRenderableWidget(new PlusIconButton(tpcLabelX + tpcLabelW + 10, tpcLabelY - 2, this::cycleTpStep));

        // Botón que abre/cierra el popup de stats efectivas (bajo el render)
        int btnW = 78, btnH = 14;
        int btnX = panelLeft + (PREVIEW_X1 + PREVIEW_X2) / 2 - btnW / 2;
        int btnY = panelTop + PREVIEW_Y2 + 4;
        this.addRenderableWidget(new TextOnlyButton(btnX, btnY, btnW, btnH,
                Component.translatableWithFallback("screen.zenkai.stats_screen.effective", "Stats"),
                () -> showEffectiveStats = !showEffectiveStats)
                .textColors(0xFFFFFF, 0xFFF149, 0xA0A0A0));

        // Barra de alineamiento (abajo-derecha)
        alignBarX = panelLeft + BG_W - 12 - ALIGN_BAR_W;
        alignBarY = panelTop + BG_H - 30;
    }

    private void spend(String attrName, int points) {
        PacketDistributor.sendToServer(new SpendTpPacket(attrName, points));
    }

    @Override
    public void render(@NotNull GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        if (mc.player == null) { super.render(g, mouseX, mouseY, partialTick); return; }
        att = mc.player.getData(ZenkaiDataAttachments.PLAYER_STATS.get());
        PlayerFormAttachment form = mc.player.getData(ZenkaiDataAttachments.PLAYER_FORM.get());

        super.render(g, mouseX, mouseY, partialTick);

        Font font = this.font;
        int left = panelLeft + 12;

        ScreenTitle.drawAbovePanel(g, font, this.title, panelLeft + BG_W / 2, panelTop);

        // ======= Cabecera: Race | Style / Form | TP (2 líneas x 2 columnas) =======
        int col2 = panelLeft + 128;
        int hy = panelTop + HEADER_Y;
        g.drawString(font, Component.translatable("screen.zenkai.stats_screen.race")
                .append(raceName().copy().withStyle(ChatFormatting.AQUA)), left, hy, 0xFFFFFF);
        g.drawString(font, Component.translatable("screen.zenkai.stats_screen.style")
                .append(styleName().copy().withStyle(ChatFormatting.AQUA)), col2, hy, 0xFFFFFF);
        hy += 11;
        g.drawString(font, Component.translatableWithFallback("screen.zenkai.stats_screen.form", "Form: ")
                .append(formName(form.getFormId()).copy().withStyle(ChatFormatting.LIGHT_PURPLE)), left, hy, 0xFFFFFF);
        g.drawString(font, Component.translatable("screen.zenkai.stats_screen.tp")
                .append(Component.literal(String.valueOf(att.getTP())).withStyle(ChatFormatting.GOLD)), col2, hy, 0xFFFFFF);

        // Divisor
        g.fill(left, panelTop + DIV_Y, panelLeft + BG_W - 12, panelTop + DIV_Y + 1, 0x44FFFFFF);

        // ======= Columna izquierda: atributos =======
        g.drawString(font, Component.translatable("screen.zenkai.stats_screen.attributes"),
                left + 4, panelTop + DIV_Y + 4, 0xFFD0D0);

        attrAreas.clear();
        int ay = panelTop + ATTR_Y0 + 2;
        int ax = panelLeft + ATTR_TEXT_X;
        for (ZenkaiAttributes a : ORDER) {
            int raw = att.getAttribute(a);
            int eff = att.getEffectiveAttribute(a);
            Component line = (eff != raw)
                    ? getAttributeLabel(a, eff + " (" + raw + ")")
                    : getAttributeLabel(a, String.valueOf(raw));
            g.drawString(font, line, ax, ay, (eff != raw) ? 0xFFD966 : 0xFFFFFF);
            attrAreas.add(new AttrArea(a, ax, ay, font.width(line), font.lineHeight));
            ay += ATTR_STEP;
        }

        // ======= Columna derecha: render del jugador =======
        int px1 = panelLeft + PREVIEW_X1, px2 = panelLeft + PREVIEW_X2;
        int py1 = panelTop + PREVIEW_Y1,  py2 = panelTop + PREVIEW_Y2;
        InventoryScreen.renderEntityInInventoryFollowsMouse(
                g, px1, py1, px2, py2, 42, 0.0625f, (float) mouseX, (float) mouseY, mc.player);

        // ======= TPC + coste =======
        g.drawString(font, Component.translatable("screen.zenkai.stats_screen.tpx", getCurrentTpStep()),
                tpcLabelX, tpcLabelY, 0xFFFFFF);
        g.drawString(font, Component.translatable("screen.zenkai.stats_screen.cost", computeCurrentTpCost()),
                tpcLabelX, tpcLabelY + font.lineHeight + 4, 0xFFFFFF);

        // ======= Barra de alineamiento =======
        renderAlignmentBar(g, font, att.getAlignment(), mouseX, mouseY);

        // ======= Popup lateral de stats efectivas =======
        if (showEffectiveStats) renderEffectiveStatsPopup(g, font);

        // ======= Tooltips =======
        renderPlayerHoverTooltip(g, form, mouseX, mouseY, px1, py1, px2, py2);
        renderAttributeTooltip(g, mouseX, mouseY);
        renderTpStepTooltip(g, mouseX, mouseY);
    }

    // ── Nombres traducibles (sin guiones bajos crudos) ───────────────────────
    private Component raceName() {
        return Component.translatable("screen.zenkai.race." + att.getRace().name().toLowerCase(Locale.ROOT));
    }
    private Component styleName() {
        return Component.translatable("screen.zenkai.style." + att.getStyle().name().toLowerCase(Locale.ROOT));
    }
    /** form.zenkai.<path con / -> .>; fallback = último segmento embellecido ("super_saiyan" -> "Super Saiyan"). */
    private static Component formName(ResourceLocation formId) {
        String key = "form." + formId.getNamespace() + "." + formId.getPath().replace('/', '.');
        String last = formId.getPath();
        int slash = last.lastIndexOf('/');
        if (slash >= 0) last = last.substring(slash + 1);
        StringBuilder pretty = new StringBuilder();
        for (String w : last.split("_")) {
            if (w.isEmpty()) continue;
            if (!pretty.isEmpty()) pretty.append(' ');
            pretty.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return Component.translatableWithFallback(key, pretty.toString());
    }

    // ── Barra de alineamiento ────────────────────────────────────────────────
    private void renderAlignmentBar(GuiGraphics g, Font font, int alignment, int mouseX, int mouseY) {
        Component label = Component.translatableWithFallback("screen.zenkai.stats_screen.alignment", "Alignment");
        g.drawString(font, label, alignBarX, alignBarY - 10, 0xFFD0D0);

        // marco + gradiente horizontal rojo -> gris -> azul (por columnas)
        g.fill(alignBarX - 1, alignBarY - 1, alignBarX + ALIGN_BAR_W + 1, alignBarY + ALIGN_BAR_H + 1, 0xFF3A2A18);
        for (int i = 0; i < ALIGN_BAR_W; i++) {
            int rgb = AlignmentPalette.gradient(i / (float) (ALIGN_BAR_W - 1));
            g.fill(alignBarX + i, alignBarY, alignBarX + i + 1, alignBarY + ALIGN_BAR_H, 0xFF000000 | rgb);
        }

        // marcador: -100..+100 -> 0..W
        int mx = alignBarX + Math.round((alignment + 100) / 200f * (ALIGN_BAR_W - 1));
        g.fill(mx - 1, alignBarY - 2, mx + 2, alignBarY + ALIGN_BAR_H + 2, 0xFFFFFFFF);

        if (mouseX >= alignBarX && mouseX < alignBarX + ALIGN_BAR_W
                && mouseY >= alignBarY - 2 && mouseY < alignBarY + ALIGN_BAR_H + 2) {
            String v = (alignment > 0 ? "+" : "") + alignment;
            g.renderTooltip(font, Component.literal(v), mouseX, mouseY);
        }
    }

    // ── Popup de stats efectivas ─────────────────────────────────────────────
    private void renderEffectiveStatsPopup(GuiGraphics g, Font font) {
        assert mc.player != null;
        boolean majin = mc.player.getData(ZenkaiDataAttachments.PLAYER_VISUAL.get()).isMajinControlled();
        List<Component> lines = buildEffectiveStats();

        // Altura dinámica: título (12) + línea majin opcional (10) + stats (10 c/u) + márgenes.
        int h = 5 + 12 + (majin ? 10 : 0) + lines.size() * 10 + 6;

        int x = panelLeft + BG_W + 6;
        if (x + POPUP_W > this.width - 2) x = panelLeft - POPUP_W - 6;
        int y = panelTop + CONTENT_TOP + 10;

        g.fill(x, y, x + POPUP_W, y + h, 0xE81E1410);
        g.fill(x, y, x + POPUP_W, y + 1, 0xFFFFAA33);
        g.fill(x, y + h - 1, x + POPUP_W, y + h, 0xFFFFAA33);
        g.fill(x, y, x + 1, y + h, 0xFFFFAA33);
        g.fill(x + POPUP_W - 1, y, x + POPUP_W, y + h, 0xFFFFAA33);

        int tx = x + 6, ty = y + 5;
        g.drawString(font, Component.translatable("screen.zenkai.stats_screen.stats"), tx, ty, 0xFFD0D0);
        ty += 12;
        if (majin) {
            g.drawString(font, Component.translatableWithFallback(
                    "screen.zenkai.stats_screen.majin_boost", "Majin +%s%%",
                    String.valueOf((int) Math.round(CommonConfig.majinStatBonus() * 100))), tx, ty, 0xFFFF5566);
            ty += 10;
        }
        for (Component c : lines) {
            g.drawString(font, c, tx, ty, 0xFFFFFF);
            ty += 10;
        }
    }

    private List<Component> buildEffectiveStats() {
        assert mc.player != null;
        // SIN formStatFactor: computeXFinal ya lo incluye vía statMultiplier. Multiplicar aquí
        // lo contaría dos veces (y era la razón de que el popup mostrara números inflados).
        double melee   = att.computeMeleeFinal();
        double defense = att.computeDefenseFinal();
        double kiPower = att.computeKiPowerFinal();

        // Los multiplicadores salen del attachment, NO de una fórmula propia: así la pantalla
        // no puede volver a desviarse de lo que aplica el movimiento de verdad.
        double moveMult = att.getMoveMultiplier();
        double flyMult  = att.getFlyMultiplier();

        List<Component> out = new ArrayList<>();
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.melee",   fmt(melee)));
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.defense", fmt(defense)));
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.body",    att.getBody() + "/" + att.getBodyMax()));
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.stamina", att.getStamina() + "/" + att.getStaminaMax()));
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.ki",      att.getEnergy() + "/" + att.getEnergyMax()));
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.ki_power", fmt(kiPower)));
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.running", (int) Math.round(moveMult * 100)));
        out.add(Component.translatable("screen.zenkai.stats_screen.stat.flying",  (int) Math.round(flyMult  * 100)));

        // Carga: solo aparece si lleva pesas. Dos líneas en vez de una para no desbordar
        // el ancho del popup. Los números salen de WeightSystem, nunca de una fórmula local.
        double load = att.getWeightLoad();
        if (load > 0.0) {
            out.add(Component.translatable("screen.zenkai.stats_screen.stat.load",
                    String.format(Locale.ROOT, "%.2f", WeightSystem.equippedTons(mc.player)),
                    String.format(Locale.ROOT, "%.2f", WeightSystem.capacityTons(att.getPowerLevelRaw())),
                    (int) Math.round(load * 100)));
            out.add(Component.translatable("screen.zenkai.stats_screen.stat.weight_tp",
                    String.format(Locale.ROOT, "%.2f", WeightSystem.tpFactor(load))));
        }
        return out;
    }

    private static String fmt(double d) { return String.format(Locale.ROOT, "%.1f", d); }

    // ── Tooltips ─────────────────────────────────────────────────────────────
    /** Hover sobre el render del jugador: forma actual + maestría, y el Kaioken si está activo. */
    private void renderPlayerHoverTooltip(GuiGraphics g, PlayerFormAttachment form,
                                          int mouseX, int mouseY, int x1, int y1, int x2, int y2) {
        if (mouseX < x1 || mouseX >= x2 || mouseY < y1 || mouseY >= y2) return;
        float mastery = form.getFormMastery(form.getFormId());
        List<Component> lines = new ArrayList<>();
        lines.add(formName(form.getFormId()));
        lines.add(Component.translatableWithFallback("screen.zenkai.stats_screen.mastery",
                "Mastery: %s%%", fmt(mastery)).withStyle(ChatFormatting.GOLD));
        // Multiplicador REAL, no el de la forma: statMultiplier ya lleva dentro forma,
        // kaioken, majin y el castigo de strain, que es exactamente lo que el jugador quiere
        // saber cuando pregunta "cuánto pego ahora mismo".
        if (att != null) {
            lines.add(Component.translatableWithFallback("screen.zenkai.stats_screen.multiplier",
            "Multiplier: x%s", fmt2(att.getStatMultiplier()))
            .withStyle(ChatFormatting.GREEN));
            }
        // Drenaje de la forma. El 0 se enseña explícitamente en vez de omitirlo: que
        // Potential Unlock no cueste ki es su razón de ser, y callarlo lo escondería.
        if (!FormIds.BASE.equals(form.getFormId())) {
            double kiPerSecond = form.formKiDrainPerTick() * 20.0;
            lines.add(kiPerSecond > 0.0
                ? Component.translatableWithFallback("screen.zenkai.stats_screen.form_drain",
            "-%s ki/s", fmt(kiPerSecond)).withStyle(ChatFormatting.AQUA)
                    : Component.translatableWithFallback("screen.zenkai.stats_screen.form_no_drain",
            "No ki cost", "No ki cost").withStyle(ChatFormatting.DARK_AQUA));
        }

        // El Kaioken es una capa APARTE de la forma y NO tiene maestría propia (son cinco
        // escalones fijos del enum). Lo que sí progresa es el nivel de la habilidad, y se
        // nota en el drenaje: por eso aquí se muestra el coste real en vida, que ya lleva
        // dentro kaiokenDrainFactor. drainPerTick es estático puro -> vale en cliente.
        KaiokenTier tier = form.getKaioken();
        if (tier.isOn() && att != null && mc.player != null) {
            double hpPerSecond = KaiokenSystem.drainPerTick(att, form,
                    SkillEffects.kaiokenDrainFactor(mc.player)) * 20.0;
            lines.add(Component.translatableWithFallback("screen.zenkai.stats_screen.kaioken",
                    "Kaioken %s", tier.label()).withStyle(ChatFormatting.RED));
            lines.add(Component.translatableWithFallback("screen.zenkai.stats_screen.kaioken_mastery",
                    "  Mastery: %s%%", fmt(form.getKaiokenMastery())).withStyle(ChatFormatting.GOLD));
            lines.add(Component.translatableWithFallback("screen.zenkai.stats_screen.kaioken_stats",
                    "  +%s%% stats", fmt(tier.statPercent() * 100.0)).withStyle(ChatFormatting.GRAY));
            lines.add(Component.translatableWithFallback("screen.zenkai.stats_screen.kaioken_drain",
                    "  -%s HP/s", fmt(hpPerSecond)).withStyle(ChatFormatting.DARK_RED));
        }
        if (att != null && mc.player != null
                && form.isStrained(mc.player.level().getGameTime())) {
            lines.add(Component.translatableWithFallback("screen.zenkai.stats_screen.kaioken_strain",
                            "Strain: %ss (-10%% stats)",
                            fmt(form.strainSecondsLeft(mc.player.level().getGameTime())))
                    .withStyle(ChatFormatting.DARK_PURPLE));
        }
        g.renderComponentTooltip(this.font, lines, mouseX, mouseY);
    }

    private void renderTpStepTooltip(GuiGraphics g, int mouseX, int mouseY) {
        if (mouseX >= tpcLabelX && mouseX < tpcLabelX + tpcLabelW &&
                mouseY >= tpcLabelY && mouseY < tpcLabelY + tpcLabelH) {
            g.renderTooltip(this.font, Component.translatable("screen.zenkai.stats_screen.tp_des"), mouseX, mouseY);
        }
    }

    private void renderAttributeTooltip(GuiGraphics g, int mouseX, int mouseY) {
        for (AttrArea area : attrAreas) {
            if (area.contains(mouseX, mouseY)) {
                g.renderTooltip(this.font, getAttributeDescription(area.attr(), att), mouseX, mouseY);
                break;
            }
        }
    }

    private int computeCurrentTpCost() {
        if (att == null) return 0;
        int step = getCurrentTpStep();
        int best = Integer.MAX_VALUE;
        for (ZenkaiAttributes a : ORDER) {
            int c = att.previewTpCost(a, step);
            if (c > 0 && c < best) best = c;
        }
        return (best == Integer.MAX_VALUE) ? 0 : best;
    }

    private Component getAttributeLabel(ZenkaiAttributes attr, String value) {
        return switch (attr) {
            case STRENGTH     -> Component.translatable("attribute.zenkai.str", value);
            case DEXTERITY    -> Component.translatable("attribute.zenkai.dex", value);
            case CONSTITUTION -> Component.translatable("attribute.zenkai.con", value);
            case WILLPOWER    -> Component.translatable("attribute.zenkai.wil", value);
            case MIND         -> Component.translatable("attribute.zenkai.mnd", value);
            case SPIRIT       -> Component.translatable("attribute.zenkai.spi", value);
        };
    }

    private Component getAttributeDescription(ZenkaiAttributes attr, PlayerStatsAttachment att) {
        Race race = att.getRace();
        Style style = att.getStyle();
        // Ahora es el rendimiento REAL por punto (lo que dice el datapack), no un
        // multiplicador abstracto. CON muestra sus dos columnas: son independientes.
        return switch (attr) {
            case STRENGTH     -> Component.translatable("tooltip.zenkai.attr.str",
                    fmt(RaceStatTable.melee(race, style)));
            case CONSTITUTION -> Component.translatable("tooltip.zenkai.attr.con",
                    fmt(RaceStatTable.health(race, style)),
                    fmt(RaceStatTable.stamina(race, style)));
            case DEXTERITY    -> Component.translatable("tooltip.zenkai.attr.dex",
                    fmt(RaceStatTable.defense(race, style)));
            case WILLPOWER    -> Component.translatable("tooltip.zenkai.attr.wil",
                    fmt(RaceStatTable.kiDamage(race, style)));
            case SPIRIT       -> Component.translatable("tooltip.zenkai.attr.spi",
                    fmt(RaceStatTable.kiReserves(race, style)));
            case MIND         -> Component.translatable("tooltip.zenkai.attr.mnd");
        };
    }

    private static String fmt2(double d) { return String.format(Locale.ROOT, "%.2f", d); }
}